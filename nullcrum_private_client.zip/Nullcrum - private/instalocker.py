import json
import requests
from valclient.client import Client
import time

agents_response = requests.get("https://valorant-api.com/v1/agents")
 
if agents_response.status_code != 200:
    print("error reaching valorant-api.com")
    time.sleep(3)
    exit(0)
 
 
agents_json  = agents_response.json()['data']
 
agent_dict = {}
 
 
 
for agent in agents_json:
 
    if agent['isPlayableCharacter'] == False:
        continue
            
    #print(f'name: {agent["displayName"]}')
    #print(f'uuid: {agent["uuid"]}')
    agent_dict[agent['displayName']] = agent['uuid']
    
 
 
print(agent_dict)
 
client = 0
 
 
 
 
 
 
try:
    client = Client()
    client.activate()
    
    local = client.fetch(endpoint="/riotclient/region-locale", endpoint_type="local")
    print("API Response:", local)
    
    api_region = local.get('region', '').lower()
    
    region_mapping = {
        'na': 'na',
        'eu': 'eu',
        'latam': 'latam',
        'br': 'br',
        'ap': 'ap',
        'kr': 'kr',
        'eune': 'eu',  # Adjust based on actual mappings
        'pbe': 'pbe',  # Adjust based on actual mappings
    }
 
    if api_region in region_mapping:
        client = Client(region=region_mapping[api_region])
        client.activate()
    else:
        raise ValueError(f"Invalid region returned from valorant API. Available regions are: {list(region_mapping.values())}")
 
except:
    print("valorant not running")
    time.sleep(3)
    exit(0)
 
   

agent = input("Agent: ").lower()
 
uuid = ''
for name in agent_dict:
 
    if name.lower() == agent.lower():
        uuid = agent_dict[name]
 
if uuid == '':
    print("agent name invalid")
    time.sleep(3)
    exit(0)
    
print(uuid)
while client.session_fetch()['loopState'] != "PREGAME":
    time.sleep(0.01)
# time.sleep(3) # possible pre select delay
client.pregame_select_character(uuid)
# time.sleep(0.3) # possible pre pick delay
client.pregame_lock_character(uuid)